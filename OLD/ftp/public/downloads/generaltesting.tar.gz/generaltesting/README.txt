See index.html and js/main.js for an example of sharing
via a Facebook App when permissions have been granted.

Set up the appId in index.html correct with the id of your app!
